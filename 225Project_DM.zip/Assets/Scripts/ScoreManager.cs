using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    int enemiesDefeated;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
